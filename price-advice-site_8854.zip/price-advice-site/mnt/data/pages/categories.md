layout: page
title: Categories
permalink: /categories/
---

Explore our most useful categories.

- Tech essentials
- Home & kitchen basics
- Travel basics
- Utilities & broadband

We link to in-depth guides and current best buys for each.
