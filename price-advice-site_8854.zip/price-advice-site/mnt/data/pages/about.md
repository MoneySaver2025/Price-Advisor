layout: page
title: About
permalink: /about/
---

We research real prices across multiple retailers, pick the best-value options, and keep it simple. We fund the site using affiliate links and, later, ads — at no extra cost to you.
