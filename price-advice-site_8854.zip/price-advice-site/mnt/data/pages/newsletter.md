layout: page
title: Newsletter
permalink: /newsletter/
---

Get weekly picks and price drops. It’s free.

- Sign up on Substack: https://substack.com (create your newsletter and paste the form embed here)
